# PocketSmart AI

Complete FastAPI + Jinja2 + SQLite + Gemini implementation based on the supplied project document.

The document contains both Flask and FastAPI references. This build follows the later FastAPI milestone and implements the documented planner, authentication, session, history, UI and multimodal jewelry requirements.

## Setup

1. Open this folder in VS Code.
2. Create a terminal and run:

Windows:
`py -3 -m venv .venv`
`.\.venv\Scripts\Activate.ps1`

macOS/Linux:
`python3 -m venv .venv`
`source .venv/bin/activate`

3. Install:
`pip install -r requirements.txt`

4. Copy `.env.example` to `.env` and add your Gemini API key. The app still runs with local fallback recommendations if the key is blank.
5. Start:
`uvicorn app.main:app --reload`
6. Open `http://127.0.0.1:8000`.
7. API docs: `http://127.0.0.1:8000/docs`.
8. Tests: `pytest -q`.

## Main routes

`/register`, `/login`, `/logout`, `/token`, `/session-info`, `/session-data`, `/generate-home`, `/generate-party`, `/generate-jewelry`, `/recommendations-details/{id}`, `/history`, `/startup`, `/health`.

## Gemini

The default model is `gemini-3.8-flash`, configured in `.env`. The original document's Gemini 1.5 Flash Pro reference is historical; use a currently supported model string when changing the configuration.

Third-party platform links are search links only. The application does not claim live product prices or inventory.
