import os
os.environ['DATABASE_PATH']='./test_pocketsmart.db';os.environ['SECRET_KEY']='test-secret';os.environ['GEMINI_API_KEY']=''
from fastapi.testclient import TestClient
from app.main import app
c=TestClient(app)
def test_health(): assert c.get('/health').json()['status']=='ok'
def test_register_login_and_home():
    email='tester@example.com'; c.post('/register',json={'name':'Tester','email':email,'password':'StrongPass123'})
    r=c.post('/login',json={'email':email,'password':'StrongPass123'}); assert r.status_code==200
    r=c.post('/generate-home',json={'budget':25000,'room_type':'Living Room','style':'Modern','requirements':'lights'}); assert r.status_code==200 and r.json()['category']=='home'
def test_protected():
    from fastapi.testclient import TestClient
    fresh=TestClient(app); r=fresh.post('/generate-party',json={'budget':10000,'event_type':'Birthday','guests':20,'venue':'Home'}); assert r.status_code==401
