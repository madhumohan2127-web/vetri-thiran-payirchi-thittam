from datetime import datetime,timedelta,timezone
from jose import jwt,JWTError
from pwdlib import PasswordHash
from .config import get_settings
ph=PasswordHash.recommended(); ALG='HS256'
def hash_password(p): return ph.hash(p)
def verify_password(p,h): return ph.verify(p,h)
def token(uid):
    s=get_settings(); exp=datetime.now(timezone.utc)+timedelta(minutes=s.access_token_expire_minutes)
    return jwt.encode({'sub':str(uid),'exp':exp},s.secret_key,algorithm=ALG)
def decode(t):
    try:return int(jwt.decode(t,get_settings().secret_key,algorithms=[ALG])['sub'])
    except (JWTError,KeyError,ValueError,TypeError):return None
