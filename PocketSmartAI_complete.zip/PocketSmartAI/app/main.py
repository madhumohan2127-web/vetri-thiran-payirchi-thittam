from contextlib import asynccontextmanager
from pathlib import Path
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware
from starlette.templating import Jinja2Templates
from .config import get_settings
from .database import init_db
from .routes import pages,auth,planners
BASE=Path(__file__).resolve().parent
@asynccontextmanager
async def lifespan(app):
    init_db();yield
s=get_settings();app=FastAPI(title=s.app_name,version='1.0.0',lifespan=lifespan)
app.add_middleware(CORSMiddleware,allow_origins=['http://127.0.0.1:8000','http://localhost:8000'],allow_credentials=True,allow_methods=['*'],allow_headers=['*'])
app.add_middleware(SessionMiddleware,secret_key=s.secret_key)
app.mount('/static',StaticFiles(directory=BASE/'static'),name='static');app.state.templates=Jinja2Templates(directory=str(BASE/'templates'))
app.include_router(pages.router);app.include_router(auth.router);app.include_router(planners.router)
if __name__=='__main__':
 import uvicorn;uvicorn.run('app.main:app',host='127.0.0.1',port=8000,reload=True)
