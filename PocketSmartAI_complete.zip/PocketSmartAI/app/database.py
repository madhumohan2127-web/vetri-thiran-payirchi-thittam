import json, sqlite3
from pathlib import Path
from .config import get_settings

def conn():
    p=Path(get_settings().database_path); p.parent.mkdir(parents=True,exist_ok=True) if str(p.parent)!='.' else None
    c=sqlite3.connect(p,check_same_thread=False); c.row_factory=sqlite3.Row; return c

def init_db():
    c=conn(); c.executescript('''CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,email TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS recommendations(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,category TEXT NOT NULL,request_json TEXT NOT NULL,response_json TEXT NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(user_id) REFERENCES users(id));'''); c.commit(); c.close()

def user_email(email):
    c=conn(); r=c.execute('SELECT * FROM users WHERE email=?',(email.lower().strip(),)).fetchone(); c.close(); return dict(r) if r else None

def user_id(uid):
    c=conn(); r=c.execute('SELECT * FROM users WHERE id=?',(uid,)).fetchone(); c.close(); return dict(r) if r else None

def create_user(name,email,password_hash):
    c=conn(); cur=c.execute('INSERT INTO users(name,email,password_hash) VALUES(?,?,?)',(name,email.lower().strip(),password_hash)); c.commit(); r=dict(c.execute('SELECT * FROM users WHERE id=?',(cur.lastrowid,)).fetchone()); c.close(); return r

def save_rec(uid,category,request_data,response_data):
    c=conn(); cur=c.execute('INSERT INTO recommendations(user_id,category,request_json,response_json) VALUES(?,?,?,?)',(uid,category,json.dumps(request_data),json.dumps(response_data))); c.commit(); rid=cur.lastrowid; c.close(); return rid

def history(uid,limit=50):
    c=conn(); rows=c.execute('SELECT * FROM recommendations WHERE user_id=? ORDER BY id DESC LIMIT ?',(uid,limit)).fetchall(); c.close(); out=[]
    for r in rows:
        d=dict(r); d['request_json']=json.loads(d['request_json']); d['response_json']=json.loads(d['response_json']); out.append(d)
    return out

def recommendation(uid,rid):
    c=conn(); r=c.execute('SELECT * FROM recommendations WHERE id=? AND user_id=?',(rid,uid)).fetchone(); c.close()
    if not r:return None
    d=dict(r); d['request_json']=json.loads(d['request_json']); d['response_json']=json.loads(d['response_json']); return d
