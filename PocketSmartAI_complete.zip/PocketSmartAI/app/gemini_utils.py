import json
from urllib.parse import quote_plus
from google import genai
from google.genai import types
from .config import get_settings

def search_url(platform,name):
    bases={'Amazon':'https://www.amazon.in/s?k=','Flipkart':'https://www.flipkart.com/search?q=','IKEA':'https://www.ikea.com/in/en/search/?q=','Swiggy':'https://www.swiggy.com/search?query=','Zomato':'https://www.zomato.com/search?q=','OYO':'https://www.oyorooms.com/search?location='}
    return bases.get(platform,'https://www.google.com/search?q=')+quote_plus(name)

def fallback(cat,budget,c):
    if cat=='home':
        raw=[('LED ceiling light','Lighting',1200,'Amazon'),('Compact side table','Furniture',3500,'IKEA'),('Wall art set','Decor',1800,'Flipkart'),('Cushion set','Soft furnishings',900,'Amazon')]
        br={'furniture':budget*.45,'lighting':budget*.2,'decor':budget*.35}; summary=f"A practical {c.get('style','modern')} setup for a {c.get('room_type','room')} within ₹{budget:,.0f}."
    elif cat=='party':
        raw=[('Catering package','Food',budget*.45,'Swiggy'),('Event decoration','Decoration',budget*.2,'Amazon'),('Venue shortlist','Venue',budget*.3,'OYO'),('Dessert option','Food',min(1800,budget*.05),'Zomato')]
        br={'food':budget*.5,'venue':budget*.3,'decoration':budget*.2}; summary=f"A balanced {c.get('event_type','event')} plan for {c.get('guests',1)} guests."
    else:
        raw=[('Statement earrings','Earrings',1499,'Amazon'),('Pendant necklace','Necklace',2199,'Flipkart'),('Bangle set','Bangles',1299,'Amazon'),('Classic bracelet','Bracelet',999,'Flipkart')]
        br={'necklace':budget*.35,'earrings':budget*.3,'bangles':budget*.2,'bracelet':budget*.15}; summary=f"Jewelry ideas for a {c.get('occasion','special occasion')} with a {c.get('style','elegant')} direction."
    return {'category':cat,'budget':budget,'summary':summary,'budget_breakdown':{k:round(v,2) for k,v in br.items()},'recommendations':[{'name':n,'category':s,'estimated_price':round(float(p),2),'platform':pl,'reason':'Fallback suggestion used when Gemini is unavailable.','search_url':search_url(pl,n)} for n,s,p,pl in raw],'tips':['Verify live prices before purchase.','Compare alternatives before spending the full budget.','Keep a small buffer for delivery, taxes, or unexpected costs.'],'source':'local-fallback'}

def extract(text):
    text=text.strip().replace('```json','').replace('```','').strip()
    try:return json.loads(text)
    except Exception:
        a,b=text.find('{'),text.rfind('}')
        try:return json.loads(text[a:b+1]) if a>=0 and b>a else None
        except Exception:return None

def generate(cat,budget,context,image=None,mime=None):
    s=get_settings(); fb=fallback(cat,budget,context)
    if not s.gemini_api_key:return fb
    prompt=f'''You are PocketSmart AI, a budget recommendation assistant. Domain={cat}. Budget INR={budget}. Context={json.dumps(context)}. Return ONLY JSON with summary, budget_breakdown, recommendations and tips. Recommendations must contain name, category, estimated_price, platform and reason. Use platform names Amazon, Flipkart, IKEA, Swiggy, Zomato or OYO only as places to search; do not claim live prices or inventory. Give 4-8 practical options and stay sensible about the budget.'''
    try:
        client=genai.Client(api_key=s.gemini_api_key); contents=[prompt]
        if image: contents.insert(0,types.Part.from_bytes(data=image,mime_type=mime or 'image/jpeg'))
        r=client.models.generate_content(model=s.gemini_model,contents=contents,config=types.GenerateContentConfig(temperature=.4,max_output_tokens=2200,response_mime_type='application/json'))
        data=extract(r.text or '')
        if not data:return fb
        items=[]
        for x in data.get('recommendations',[])[:8]:
            n=str(x.get('name','Suggested item')); pl=str(x.get('platform','Amazon'))
            items.append({'name':n,'category':str(x.get('category','General')),'estimated_price':float(x.get('estimated_price',0) or 0),'platform':pl,'reason':str(x.get('reason','Fits the stated budget and preferences.')),'search_url':x.get('search_url') or search_url(pl,n)})
        if not items:return fb
        return {'category':cat,'budget':budget,'summary':str(data.get('summary','Your AI-generated plan.')),'budget_breakdown':data.get('budget_breakdown',{}),'recommendations':items,'tips':[str(x) for x in data.get('tips',[])][:8],'source':'gemini','raw_text':r.text}
    except Exception:return fb
