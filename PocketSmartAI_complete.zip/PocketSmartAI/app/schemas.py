from pydantic import BaseModel,EmailStr,Field
class Register(BaseModel): name:str=Field(min_length=2,max_length=80); email:EmailStr; password:str=Field(min_length=8,max_length=128)
class Login(BaseModel): email:EmailStr; password:str=Field(min_length=1,max_length=128)
class Home(BaseModel): budget:float=Field(gt=0); room_type:str; style:str='Modern'; requirements:str=''
class Party(BaseModel): budget:float=Field(gt=0); event_type:str; guests:int=Field(gt=0); venue:str='Flexible'; preferences:str=''
