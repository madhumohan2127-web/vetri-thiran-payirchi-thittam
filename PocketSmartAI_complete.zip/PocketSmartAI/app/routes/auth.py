from fastapi import APIRouter,Request,Form,HTTPException
from fastapi.responses import JSONResponse,RedirectResponse
from ..schemas import Register,Login
from ..database import user_email,create_user
from ..security import hash_password,verify_password,token
router=APIRouter()
@router.post('/register')
def register(p:Register):
    if user_email(p.email):raise HTTPException(409,'Email is already registered.')
    u=create_user(p.name,p.email,hash_password(p.password));return {'message':'Registration successful','user':{'id':u['id'],'name':u['name'],'email':u['email']}}
@router.post('/register-form')
def register_form(request:Request,name:str=Form(...),email:str=Form(...),password:str=Form(...)):
    try:register(Register(name=name,email=email,password=password))
    except Exception as e:return request.app.state.templates.TemplateResponse('register.html',{'request':request,'error':getattr(e,'detail',str(e))},status_code=400)
    return RedirectResponse('/login?registered=1',303)
@router.post('/login')
def login(p:Login):
    u=user_email(p.email)
    if not u or not verify_password(p.password,u['password_hash']):raise HTTPException(401,'Invalid email or password.')
    t=token(u['id']);r=JSONResponse({'access_token':t,'token_type':'bearer'});r.set_cookie('pocketsmart_session',t,httponly=True,samesite='lax',max_age=7200);return r
@router.post('/login-form')
def login_form(request:Request,email:str=Form(...),password:str=Form(...)):
    try: r=login(Login(email=email,password=password)); t=r.body.decode().split('"access_token":"')[1].split('"')[0]
    except Exception as e:return request.app.state.templates.TemplateResponse('login.html',{'request':request,'error':getattr(e,'detail',str(e))},status_code=400)
    out=RedirectResponse('/dashboard',303);out.set_cookie('pocketsmart_session',t,httponly=True,samesite='lax',max_age=7200);return out
@router.post('/token')
def token_route(p:Login):return login(p)
@router.post('/logout')
def logout():r=RedirectResponse('/login?logged_out=1',303);r.delete_cookie('pocketsmart_session');return r
@router.get('/session-info')
def session_info(request:Request):
    from ..security import decode
    from ..database import user_id
    t=request.cookies.get('pocketsmart_session');u=user_id(decode(t)) if t and decode(t) else None
    return {'authenticated':bool(u),'user_id':u['id'] if u else None,'name':u['name'] if u else None,'email':u['email'] if u else None}
@router.get('/session-data')
def session_data(request:Request):
    i=session_info(request)
    from ..database import history
    return {'authenticated':i['authenticated'],'data':{'recent_recommendations':history(i['user_id'],5)} if i['authenticated'] else {}}
