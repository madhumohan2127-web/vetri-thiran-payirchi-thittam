from fastapi import APIRouter,Depends,UploadFile,File,Form,HTTPException
from ..dependencies import current_user
from ..schemas import Home,Party
from ..gemini_utils import generate
from ..database import save_rec
from ..config import get_settings
router=APIRouter()
def save(u,cat,budget,c,image=None,mime=None):
    result=generate(cat,budget,c,image,mime);rid=save_rec(u['id'],cat,{'budget':budget,**c,'image_attached':bool(image)},result);result['recommendation_id']=rid;return result
@router.post('/generate-home')
def home(p:Home,u=Depends(current_user)):return save(u,'home',p.budget,p.model_dump(exclude={'budget'}))
@router.post('/generate-party')
def party(p:Party,u=Depends(current_user)):return save(u,'party',p.budget,p.model_dump(exclude={'budget'}))
@router.post('/generate-jewelry')
async def jewelry(budget:float=Form(...),occasion:str=Form(...),style:str=Form('Elegant'),outfit_description:str=Form(''),outfit_image:UploadFile|None=File(None),u=Depends(current_user)):
    if budget<=0:raise HTTPException(422,'Budget must be greater than zero.')
    image=None;mime=None
    if outfit_image and outfit_image.filename:
        image=await outfit_image.read();mime=outfit_image.content_type or 'image/jpeg'
        if len(image)>get_settings().max_image_size_mb*1024*1024:raise HTTPException(413,'Image is too large.')
        if not mime.startswith('image/'):raise HTTPException(400,'Only image uploads are supported.')
    return save(u,'jewelry',budget,{'occasion':occasion,'style':style,'outfit_description':outfit_description},image,mime)
