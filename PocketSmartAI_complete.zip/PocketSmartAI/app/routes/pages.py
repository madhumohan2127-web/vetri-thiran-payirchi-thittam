from fastapi import APIRouter,Request,Depends,HTTPException
from ..dependencies import current_user
from ..database import history,recommendation
router=APIRouter()
def page(request,t,**c):return request.app.state.templates.TemplateResponse(t,{'request':request,**c})
@router.get('/')
def home_page(request:Request):return page(request,'index.html')
@router.get('/register')
def register_page(request:Request):return page(request,'register.html')
@router.get('/login')
def login_page(request:Request):return page(request,'login.html')
@router.get('/dashboard')
def dashboard(request:Request,u=Depends(current_user)):return page(request,'dashboard.html',user=u,history=history(u['id'],8))
@router.get('/home-planner')
def hp(request:Request,u=Depends(current_user)):return page(request,'home_planner.html',user=u)
@router.get('/party-planner')
def pp(request:Request,u=Depends(current_user)):return page(request,'party_planner.html',user=u)
@router.get('/jewelry-planner')
def jp(request:Request,u=Depends(current_user)):return page(request,'jewelry_planner.html',user=u)
@router.get('/history')
def hist(request:Request,u=Depends(current_user)):return page(request,'history.html',user=u,history=history(u['id']))
@router.get('/recommendations-details/{rid}')
def detail(request:Request,rid:int,u=Depends(current_user)):
    x=recommendation(u['id'],rid)
    if not x:raise HTTPException(404,'Recommendation not found')
    return page(request,'recommendations.html',user=u,recommendation=x['response_json'],request_data=x['request_json'])
@router.get('/testimonials')
def testimonials(request:Request):return page(request,'testimonials.html')
@router.get('/startup')
def startup():return {'status':'ready'}
@router.get('/health')
def health():return {'status':'ok'}
