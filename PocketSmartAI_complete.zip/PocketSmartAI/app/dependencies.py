from fastapi import Request,HTTPException
from .security import decode
from .database import user_id

def current_user(request:Request):
    t=request.cookies.get('pocketsmart_session')
    if not t and request.headers.get('Authorization','').lower().startswith('bearer '): t=request.headers['Authorization'][7:]
    uid=decode(t) if t else None; u=user_id(uid) if uid else None
    if not u: raise HTTPException(401,'Login required')
    return u
